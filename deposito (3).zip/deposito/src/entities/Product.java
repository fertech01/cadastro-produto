package entities;

public class Product {

	// Declarando variáveis.

	// IMPORTANTE: Não se esqueça de que o atributo é public!!! Caso contrário, não
	// funcionará...

	// EXCETO... queira fazer um encapsulamento, como no código abaixo.

	private String nome;
	private String marca;
	private int quantidade;
	private double valor;

	// Construtor padrão.
	public Product() {

	}

	// Customizando o construtor.
	public Product(String nome, String marca, double valor, int quantidade) {
		this.nome = nome;
		this.marca = marca;
		this.valor = valor;
		this.quantidade = quantidade;

	}

	// Construtor opcional (sobrecarga).
	// Sobrecarga é quando você disponibiliza mais de uma versão de uma função.
	public Product(String nome, String marca) {
		this.nome = nome;
		this.marca = marca;
		quantidade = 0;
		valor = 0.00;
	}

	// Métodos setters e getters.

	// Basicamente, em encapsulamento, para usar uma variável private, você precisa
	// criar um método para selecionar o atributo (get) e outro para defini-lo
	// (set).

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getMarca() {
		return marca;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	// Criando métodos.
	public double valorTotalEstoque() {
		return quantidade * valor;
	}

	public void addEstoque(int quantidade) {
		// this serve para auto referenciar um parâmetro do método.
		this.quantidade += quantidade;
	}

	public void removeProduto(int quantidade) {
		this.quantidade -= quantidade;
	}

	// Você precisa declarar como você quer que a variável apareça utilizando
	// toString().

	public String toString() {
		return "Produto: " + getNome() + ", marca: " + getMarca() + " - R$ " + String.format("%.2f", getValor())
				+ " - Unidades: " + getQuantidade() + " - Valor total no estoque:R$ "
				+ String.format("%.2f", valorTotalEstoque());
	}
}
