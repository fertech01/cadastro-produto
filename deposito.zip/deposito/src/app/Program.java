package app;

import java.util.Locale;
import java.util.Scanner;

import entities.Product;

public class Program {
	public static void main(String[] args) {

		// Chamando libraries...
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);
		Product produto = new Product();

		// Declarando variáveis
		String nome = null;
		String marca = null;
		double valor = 0;
		int quantidade = 0;
		boolean flag = true;

		// Input & loop infinito...

		while (flag == true) {
			System.out.println("");
			System.out.println("               Cadastro de produtos.           ");
			System.out.println("-----------------------------------------------");
			System.out.println("");
			System.out.printf("Pressione [0] - Encerrar o programa%n" + "Pressione [1] - Cadastrar produto%n"
					+ "Pressione [2] - Adicionar unidade%n" + "Pressione [3] - Remover unidade%n"
					+ "Pressione [4] - Verificar estoque");

			System.out.println();
			int resp = sc.nextInt();

			// Verificando resposta

			// Cadastrar novo produto.
			switch (resp) {
			case 1:
				System.out.print("Nome do produto: ");
				sc.nextLine();
				nome = sc.nextLine();

				System.out.println("Marca: ");
				marca = sc.nextLine();

				System.out.print("Preço do produto: R$");
				valor = sc.nextDouble();

				System.out.print("Quantidade em estoque: ");
				quantidade = sc.nextInt();

				produto.setNome(nome);
				produto.setValor(valor);
				produto.setMarca(marca);
				produto.setQuantidade(quantidade);

				if (quantidade > 0 && valor > 0 && nome != null && marca != null) {
					System.out.println("Produto cadastrado com sucesso!");
					break;
				} else {
					System.out.println("ERRO: As informações inseridades são inválidas!");
				}

				// Adicionar unidades...
			case 2:
				if (nome == null) {
					System.out.println("ERRO: Não há nenhum produto cadastrado ainda!");
					System.out.println();
				} else {
					System.out.println("-----------------------------------------------");
					System.out.print("Unidades novas a serem adicionadas no estoque: ");
					quantidade = sc.nextInt();
					if (quantidade > 0) {
						produto.addEstoque(quantidade);
						System.out.println("Atualização: ");
						System.out.println(produto);
					}
				}
				break;

			// Remove unidades...
			case 3:
				if (nome == null) {
					System.out.println("ERRO: Não há nenhum produto cadastrado ainda!");
					System.out.println();
				} else {
					System.out.print("Unidades a serem removidas: ");
					quantidade = sc.nextInt();
					if (quantidade > 0) {
						produto.removeProduto(quantidade);
						System.out.println("Atualização: ");
						System.out.println(produto);
					}
				}

				// Verifica estoque...
			case 4:
				if (nome == null && quantidade == 0) {
					System.out.println("ERRO: O estoque está vazio!");
				} else {
					System.out.println("Produtos no estoque: ");
					System.out.println(produto);
				}
				break;

			// Encerra o programa...
			case 0:
				System.out.println("Encerrando o programa...");
				flag = false;
				sc.close();

			}

		}
	}
}
